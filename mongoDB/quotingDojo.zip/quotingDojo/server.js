// require express
var express = require("express");
// create the express app
var app = express();
// require body-parser
var bp = require('body-parser');
//use body-parser
app.use(bp.urlencoded({extended: true}));
// require path
var path = require("path");
// follow path to set up static content
app.use(express.static(path.join(__dirname, "./static")));
// require mongoose
var mongoose = require("mongoose");
// Use native promises
mongoose.Promise = global.Promise;
// connect mongoose to mongodb
mongoose.connect("mongodb://localhost/dojoMessageBoard")

// create dbs
var Schema = mongoose.Schema;

var QuoteSchema = new Schema({
  name: {type: String, required: true, minlength: 3},
  content: {type: String, required: true},
}, {timestamps:true})

//setters
mongoose.model('Quote', QuoteSchema);

//getters
var Quote = mongoose.model('Quote');

// setting up ejs and our views folder
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

// root route to render the index.ejs view
app.get('/', function(req, res) {
  res.render("index");
})
app.post('/quotes', function(req, res) {
  var quote = new Quote(req.body);
  quote.save(
    function(err){
    if (err){
      console.log(err);
      res.render('index', {title: 'you have errors!', errors: quote.errors})
    } else {
        res.redirect('/quotes');
      }
  })
})
app.get('/quotes', function(req, res) {
  Quote.find({})
  .exec(function(err, quotes){
    if(err){console.log(err);}
    res.render("quotes", {quotes});
  })
})
// tell the express app to listen on port 8000
var server = app.listen(8000, function() {
  console.log("listening on port 8000");
})
