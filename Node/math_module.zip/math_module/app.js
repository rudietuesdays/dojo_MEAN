var mathlib = require('./mathlib')();
mathlib.add(10,5);
mathlib.multiply(2,3);
mathlib.square(5)
mathlib.random(2,17)
