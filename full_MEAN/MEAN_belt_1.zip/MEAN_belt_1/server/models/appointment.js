console.log('loading appointment model...');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var AppointmentSchema = new Schema({
  date: {
    type: Date,
    required: [true, 'enter desired date'],
    // validate: {
    //   validator: function(value){
    //     var now = moment();
    //     console.log('************', value, now);
    //     return value > Date.now;
    //   },
    //   message: "appointment must be scheduled for a future date"
    // }
  },

  time: {
    type: Number,
		required: [true, 'select a time']
  },

  complaint: {
    type: String,
		required: [true, 'enter reason for coming in'],
    minlength: [10, 'enter a more detailed complaint']
  },

  _patient: {type: Schema.Types.ObjectId, ref: 'Patient'}

},{timestamps:true})

// AppointmentSchema.pre('save', function(done){
//   var apptCount = Appointment.where('date', req.body.date).count(function (err, count) {
//     if (err) return handleError(err);
//     console.log('there are %d appts', count);
//     if (count >= 3 ){
//       done(res.json({
//         errors: {
//           message: 'that day is full, please select a different day',
//           kind: 'what did not work',
//           path: 'appointment create',
//           value: 'appt create error'
//         }
//       }))
//     }
//   })
// })

mongoose.model('Appointment', AppointmentSchema);
